# Multiple Wishlist Sample Data Functional Tests

The Functional Test Module for **Magento MultipleWishlistSampleData** module.
